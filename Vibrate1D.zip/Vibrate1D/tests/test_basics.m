function test_basics()
% Unit-ish checks for Vibrate1D

% use project-relative path: /tests -> /inst
thisDir = fileparts(mfilename('fullpath'));
addpath(fullfile(thisDir,'..','inst'));

% 1) vib_time length & end time
t = vib_time(1000, 0.5);
assert(isvector(t), 't must be a vector');
assert(abs(t(end) - 0.5) < 1e-12, 'end time mismatch');

% 2) vib_free sanity (underdamped decay)
[~, x] = vib_free(1, 0.2, 20, linspace(0,1,101), 0.1, 0);
assert(max(abs(x)) <= 0.11, 'unexpected amplitude > expected');

% 3) vib_fr peak near wn
wn = sqrt(20);
w  = linspace(0, 3*wn, 1000);
[omega, mag, ~] = vib_fr(1,0.2,20,w);
[~, idx] = max(mag);
assert(abs(omega(idx) - wn) < 0.15*wn, 'peak frequency not near wn');

disp('test_basics passed');
end
