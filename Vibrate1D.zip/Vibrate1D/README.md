# Vibrate1D (single-DOF mass–spring–damper)

## Folders
- `inst/` – core functions (`vib_time`, `vib_free`, `vib_forced`, `vib_fr`, `vib_plots`)
- `demos/` – `demo_damping.m` (time response), `demo_curve.m` (FR curve)
- `tests/` – `test_basics.m`

## How to run
1. Open `run_all.m` at the project root.
2. Click **Run**. Outputs are saved to `figs/` as PNGs.
