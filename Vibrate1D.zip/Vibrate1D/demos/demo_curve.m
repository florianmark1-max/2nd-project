% --- path prelude ---
thisDir = fileparts(mfilename('fullpath'));
addpath(fullfile(thisDir,'..','inst'));
if ~exist(fullfile(thisDir,'..','figs'),'dir')
    mkdir(fullfile(thisDir,'..','figs'));
end

% --- Frequency-response demo ---
m=1; k=100; c=0.5; wn = sqrt(k/m);
w = linspace(0, 3*wn, 2000);
[omega, mag, phase] = vib_fr(m,c,k,w);

figure('visible','off');
subplot(2,1,1);
plot(omega,mag); grid on
xlabel('\omega (rad/s)'); ylabel('|H(j\omega)|');
title('Frequency response magnitude');
[mm,idx] = max(mag); hold on
plot(omega(idx),mm,'ro');
text(omega(idx),mm,sprintf(' peak @ %.2f rad/s',omega(idx)));

subplot(2,1,2);
plot(omega,phase); grid on
xlabel('\omega (rad/s)'); ylabel('Phase (rad)');
title('Frequency response phase');

print('-dpng', fullfile(thisDir,'..','figs','fr_curve.png'));
close;
