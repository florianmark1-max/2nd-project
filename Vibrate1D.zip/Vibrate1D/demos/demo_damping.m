% --- path prelude ---
thisDir = fileparts(mfilename('fullpath'));
addpath(fullfile(thisDir,'..','inst'));
if ~exist(fullfile(thisDir,'..','figs'),'dir')
    mkdir(fullfile(thisDir,'..','figs'));
end

% --- Damping comparison demo ---
fs = 2000;  T = 1.0; 
t  = vib_time(fs, T);
m = 1;  k = 100;  x0 = 0.1;  v0 = 0;

c_und  = 2*m*sqrt(k/m)*0.2;  % 20% critical
c_crit = 2*m*sqrt(k/m);
c_over = 2*m*sqrt(k/m)*2;

[~, x1] = vib_free(m,c_und, k,t,x0,v0);
[~, x2] = vib_free(m,c_crit,k,t,x0,v0);
[~, x3] = vib_free(m,c_over,k,t,x0,v0);

figure('visible','off');
plot(t,x1,'-','LineWidth',1); hold on
plot(t,x2,'--','LineWidth',1);
plot(t,x3,':','LineWidth',1);
xlabel('Time (s)'); ylabel('x (m)');
legend('underdamped','critical','overdamped');
title('Damping comparison'); grid on
print('-dpng', fullfile(thisDir,'..','figs','damping_compare.png'));
close;