clear; clc; close all;

% project root
projDir = fileparts(mfilename('fullpath'));

% add folders to path
addpath(fullfile(projDir,'inst'));    % functions
addpath(fullfile(projDir,'demos'));   % demos

% quick smoke check
t = vib_time(2000,0.5);
fprintf('dt = %.6g s, N = %d\n', t(2)-t(1), numel(t));

% ensure figs/ exists
if ~exist(fullfile(projDir,'figs'),'dir')
    mkdir(fullfile(projDir,'figs'));
end

% run your demos
demo_damping;    % damping comparison
demo_curve;        % FR curve

% run tests if present
if exist(fullfile(projDir,'tests','test_basics.m'),'file')
    addpath(fullfile(projDir,'tests'));   % make sure tests/ is on path
    test_basics();                        % call by name
end

disp('✅ Done. Check the figs/ folder for PNG outputs.');

