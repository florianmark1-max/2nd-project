function [t, x] = vib_free(m, c, k, t, x0, v0)
% vib_free Compute free response x(t) of single-DOF linear mass-spring-damper
%
% [t, x] = vib_free(m, c, k, t, x0, v0)
% Inputs:
% m - mass (kg), scalar >0
% c - damping coeff (N·s/m), scalar >= 0
% k - stiffness (N/m), scalar >0
% t - time vector (row or col)
% x0 - initial displacement at t=0
% v0 - initial velocity at t=0
% Outputs:
% t - same time vector (returned for convenience)
% x - displacement vector same shape as t
%
% Example:
% t = vib_time(1000,1);
% [t,x] = vib_free(1,0.1,20,t, 0.1, 0);
% input checks
if ~(isscalar(m) && m>0)
error('m must be positive scalar');
end
if ~(isscalar(k) && k>0)
error('k must be positive scalar');
end
if ~(isscalar(c) && c>=0)
error('c must be nonnegative scalar');
end
omega_n = sqrt(k/m);
zeta = c / (2*m*omega_n);
x = zeros(size(t));
if zeta < 1 % underdamped: closed form
wd = omega_n*sqrt(1 - zeta^2);
A = x0;
B = (v0 + zeta*omega_n*x0)/wd;
x = exp(-zeta*omega_n.*t).*(A*cos(wd.*t) + B*sin(wd.*t));
elseif abs(zeta-1) < 1e-8 % critically damped
A = x0;
B = v0 + omega_n*x0;
x = (A + B.*t).*exp(-omega_n.*t);
else % overdamped
s1 = -omega_n*(zeta - sqrt(zeta^2-1));
s2 = -omega_n*(zeta + sqrt(zeta^2-1));
C1 = (v0 - s2*x0)/(s1 - s2);
C2 = x0 - C1;
x = C1*exp(s1.*t) + C2*exp(s2.*t);
end

