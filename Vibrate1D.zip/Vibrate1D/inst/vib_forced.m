function [t, x] = vib_forced(m, c, k, t, Ffun, x0, v0)
% vib_forced Numerical forced-response using simple RK4 (time-domain)
%
% [t, x] = vib_forced(m,c,k,t,Ffun,x0,v0)
% Inputs:
% m,k,c - system params (scalars)
% t - time vector (row)
% Ffun - handle @(tau) returning force at time tau (scalar)
% x0,v0 - initial condition
% Outputs:
% t - time vector
% x - displacement vector
%
% Example:
% t = vib_time(2000,0.2);
% Ffun = @(tau) 1.0*sin(2*pi*50*tau);
% [t,x] = vib_forced(1,0.2,100,t,Ffun,0,0);
if ~isa(Ffun,'function_handle')
error('Ffun must be a function handle of time');
end
dt = t(2)-t(1);
n = length(t);
x = zeros(size(t));
v = zeros(size(t));
x(1) = x0;
v(1) = v0;
for i = 1:n-1
ti = t(i);
% state vector [x; v], dx/dt=v, dv/dt=(F - c v - k x)/m
fx = @(tt, xx, vv) vv;
fv = @(tt, xx, vv) (Ffun(tt) - c*vv - k*xx)/m;
% RK4 steps
k1x = fx(ti,x(i),v(i));
k1v = fv(ti,x(i),v(i));
k2x = fx(ti+dt/2, x(i)+dt*k1x/2, v(i)+dt*k1v/2);
k2v = fv(ti+dt/2, x(i)+dt*k1x/2, v(i)+dt*k1v/2);
k3x = fx(ti+dt/2, x(i)+dt*k2x/2, v(i)+dt*k2v/2);
k3v = fv(ti+dt/2, x(i)+dt*k2x/2, v(i)+dt*k2v/2);
k4x = fx(ti+dt, x(i)+dt*k3x, v(i)+dt*k3v);
k4v = fv(ti+dt, x(i)+dt*k3x, v(i)+dt*k3v);
x(i+1) = x(i) + dt*(k1x + 2*k2x + 2*k3x + k4x)/6;
v(i+1) = v(i) + dt*(k1v + 2*k2v + 2*k3v + k4v)/6;
end

