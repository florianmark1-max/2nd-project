function [omega, mag, phase] = vib_fr(m, c, k, omega_vec)
% vib_fr Frequency response H(jw) = X/F for SDOF
% [omega, mag, phase] = vib_fr(m,c,k,omega_vec)
% Inputs:
% m,c,k - system params
% omega_vec - vector of rad/s frequencies to evaluate
% Outputs:
% omega - same as omega_vec
% mag - magnitude |H(jw)| (same shape)
% phase - phase in radians
%
% Example:
% w = linspace(0,500,1000);
% [w,mag,phi] = vib_fr(1,0.1,100,w);
s = 1j*omega_vec;
H = 1 ./ (m*s.^2 + c*s + k);
mag = abs(H);
phase = angle(H);
omega = omega_vec;
end
